Median iOS
============

This is the native iOS code used by https://median.co/

It allows the creation of full-featured native apps from existing mobile-optimized websites.

How to use
------------

Build instructions at https://median.co/docs/build-ios-from-source

Licensing information available at https://median.co/license
